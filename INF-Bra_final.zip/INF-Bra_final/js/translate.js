//define current active language
let language = document.getElementsByTagName("html")[0].getAttribute("lang");

if (language == "en") {
  console.log("test englsich");
} else {
}
